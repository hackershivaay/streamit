<?php
if ( !defined('ABSPATH') ) {
	exit('Direct access denied.');
}
?>
<div id="ws_capability_suggestions" style="display: none;">
	<p id="ws_previewed_caps">&nbsp;</p>
	<table class="widefat striped">
		<thead>
		<tr>
			<th class="ws_ame_role_name">Role</th>
			<th>Suggestion</th>
		</tr>
		</thead>
		<tbody>
		<tr><td colspan="2">This table will be populated by JavaScript</td></tr>
		</tbody>
	</table>
</div>