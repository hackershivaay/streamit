export default {
  id: {
    type: Number,
    default: 0,
  },
  title: {
    type: String,
    default: "",
  },
  duration: {
    type: String,
    default: "",
  },
};
