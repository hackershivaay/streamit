import attributes from "./attributes";

export default {
  attributes,

  category: "presto",

  supports: {
    align: true,
  },

  // dynamic save function
  save: function () {
    return null;
  },
};
