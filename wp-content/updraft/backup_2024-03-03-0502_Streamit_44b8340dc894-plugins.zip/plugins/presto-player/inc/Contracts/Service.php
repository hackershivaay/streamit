<?php

namespace PrestoPlayer\Contracts;

interface Service
{
    public function register();
}
