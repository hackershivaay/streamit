== DooPlay ==
Contributors: Doothemes Team
Requires at least: WordPress 5+
Tested up to: WordPress 5.7.2
Version: 2.5.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Copyright ==

DooPlay WordPress Theme, Copyright 2016-2021 Doothemes.com & themes.pe

== Documentation ==

https://dooplay.themes.pe

== Change Log ==

https://dooplay.themes.pe/changelog
