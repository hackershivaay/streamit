<div class="cookies-warning position-fixed">
	<div class="container-fluid">
		<div class="row">
			<div class="col">
				<div class="alert alert-cookies alert-dismissible"><?php echo dooplay_get_option('cookie_text'); ?> <a href="/privacy" class="alert-cookies__link"><?php echo dooplay_get_option('cookie_text_readmore'); ?></a>
					<a href="#" type="button" class="close alert-cookies__close" data-dismiss="alert">
						<span>×</span>
					</a>
				</div>
			</div>
		</div>
	</div>
</div>
